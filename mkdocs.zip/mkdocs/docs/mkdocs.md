##mkdocs document
 ## mkdocs 

apt install mkdocs.

mkdocs --help.

mkdocs new hello-pkg.

then if u want see ur location write : ls. 

u must exsit in thiis location : ~/Documents/JDevs/MKTuts.

then write cd hello-pkg.

then open sublime text ====> type this command ====> subl ..

after open file mkdocs .yml and wrote name of ur files.

then in terminal write ===> ls.

then type ===> mkdocs serve.

after this command copy http://127.0.0.1:8000 and open. 

chrome or another browser.

then in subl. change text in index.md.
