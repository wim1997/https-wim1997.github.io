##python csv

 1  apt install ssh.

    2  ip a.

    3  ip as.
    
    4  ip a.
    
    5  ping google.com.
    
    6  nmtui.
    
    7  reboot.
    
    8  exit.
    
    9  cd.
   
   10  clear.
   
   11  ip a.
   
   12  clear.
   
   13  ip a.
   
   14  sudo -i.
   
   15  exit.
   
   16  cat /etc/passwd.
   
   17  ip a.
   
   18  systemctl sttaus sshd.
   
   19  systemctl status sshd.
   
   20  clear.
   
   21  df -h.
   
   22  clear.
   
   23  history.
   
   24  exit.
   
   25  history.
   
   26  exit.
   
   27  clear.
   
   28  apt install docker.
   
   29  systemct; status docker.
   
   30  systemctl status docker.
   
   31  systemctl status docker.io.
   
   32  apt-get install docker.
   
   33  sudo apt-get remove docker docker-engine docker.io containerd runc.
   
   34  sudo apt-get update.
   
   35  sudo apt-get install     ca-certificates     curl     gnupg     lsb-release.
   
   36  cat lsb_release.
   
   37  cat etc/lsb_release.
   
   38  cat /etc/lsb_release.
   
   39  lsb_relase -v.
   
   40  lsb_release -v.
   
   41  apt install lsb.
   
   42  curl -fsSL https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo apt-key add -.
   
   43  vi /etc/resolv.conf. 
   
   44  curl -fsSL https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo apt-key add -.
   
   45  echo "deb https://artifacts.elastic.co/packages/7.x/apt stable main" | sudo tee -a /etc/apt/sources.list.d/elastic-7.x.list.
   
   46  :paste.
   
   47  sudo apt-get install ca-certificates.
   
   48  curl -fsSL https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo apt-key add -.
   
   49  echo "deb https://artifacts.elastic.co/packages/7.x/apt stable main" | sudo tee -a /etc/apt/sources.list.d/elastic-7.x.list.
   
   50  sudo apt update.
   
   51  clear.
   
   52  sudo apt install elasticsearch.
   
   53  ip a.
   
   54  cleart.
   
   55  clear.
   
   56  ip -c a.
   
   57  systemctl status sshd.
   
   58  clear.
   
   59  ls.
   
   60  ip a.
   
   61  systemctl restart networking.
   
   62  reboot.
   
   63  clear.
   
   64  cd.
   
   65  clear.
   
   66  ip a.
   
   67  ping google.com.
   
   68  df -.
   
   69  df -h.
   
   70  htop.
   
   71  apt install htop.
   
   72  htop.
   
   73  clear.
   
   75  :pastesudo apt install elasticsearch.
   
   76  vi /etc/resolv.conf.
   
   77  sudo vi /etc/elasticsearch/elasticsearch.yml.
   
   78  apt install vim.

   79  sudo vim /etc/elasticsearch/elasticsearch.yml.
   
   80  syytemctl start elasticsearch.
   
   81  systemctl start elasticsearch.
   
   82  syystemctl sttaus elasticsearch.
   
   83  syystemctl status elasticsearch.
   
   84  systemctl status elasticsearch.
   
   85  clear.
   
   86  curl -X GET "localhost:9200".
   
   87  sudo ln -s /etc/nginx/sites-available/your_domain /etc/nginx/sites-enabled/your_domain.
   
   88  sudo vim /etc/nginx/sites-available/your_domain.
   
   89  sudo nano /etc/nginx/sites-available/your_domain.
   
   90  sudo vim /etc/nginx/sites-available/your_domain.
   
   91  sudo cd /etc/nginx/sites-available/your_domain.
   
   92  sudo cd /etc/nginx/sites-available/.
   
   93  cd /etc/nginx/sites-available/.
   
   94  cd /etc/nginx.
   
   95  apt install nginx.
   
   96  systemctl status nginx.
   
   97  clear.
   
   98  cd /etc/nginx/sites-available/.
   
   99  ls.
  
  100  sudo cd /etc/nginx/sites-available/your_domain.
  
  101  sudo cd /etc/nginx/sites-available/default.
  
  102  sudo cd /etc/nginx/sites-available.
  
  103  ls.
  
  104  vim default. 
  
  105  sudo vim /etc/nginx/sites-available/your_domain.
  
  106  systemctl restart nginx.
  
  107  systemctl status nginx.
  
  108  clear.
  
  109  sudo apt install logstash.
  
  110  systemctl status logstach.
  
  111  systemctl status logstasch.
  
  112  systemctl start logstash.
  
  113  sudo apt install logstash.
  
  114  vim /etc/resolv.conf.
  
  115  sudo apt install logstash.
  
  116  systemctl start logstash.
  
  117  systemctl status logstash.
  
  118  clear.
  
  119  curl -XGET 'http://localhost:9200/filebeat-*/_search?pretty'.
  
  120  ls.
  
  121  cd.
  
  122  pd.
  
  123  pwd.
  
  124  clear.
  
  125  cd opt.
  
  126  cd /opt.
  
  127  ls.
  
  128  touch input.csv.
  
  129  ls.
  
  130  touch output.json.
  
  131  ls.
  
  132  vim csv.py.
  
  133  ls.
  
  134  python3 csv.py. 
  
  135  vim csv.py.
  
  136  python3 csv.py. 
  
  137  vim csv.py.
  
  138  python3 csv.py. 
  
  139  vim csv.py.
  
  140  ls.
  
  141  vim input.csv. 
  
  142  python3 csv.py. 
  
  143  vim input.csv.
  
  144  vim csv.py.
  
  145  python3 csv.py. 
  
  146  clear.
  
  147  cd /opt.
  
  148  ls.
  
  149  python3 csv.py. 
  
  150  vim csv.py.
  
  151  vim cvv.py.
  
  152  python3 cvv.py. 
  
  153  vim cvv.py.
  
  154  python3 cvv.py. 
  
  155  vim cvv.py.
  
  156  python3 cvv.py. 
  
  157  vim cvv.py.
  
  158  ls.
  
  159  rm csv.py.
  
  160  ls.
  
  161  python3 cvv.py. 
  
  162  cat output.json. 
  
  163  vim /etc/logstash/conf.d.
  
  164  vim /etc/logstash/conf.d/import_csv.conf.
  
  165  vim cvv.py.
  
  166  curl localhost:9200.
  
  167  curl -XGET 'http://localhost:9200/filebeat-*/_search?pretty'.
  
  168  vim /etc/elasticsearch/elasticsearch.yml.
  
  169  curl -XGET 'http://localhost:9200/filebeat-*/_search?pretty'.
  
  170  vim /etc/elasticsearch/elasticsearch.yml.
  
  171  curl -XGET 'http://localhost:9200/filebeat-*/_search?pretty'.
  
  172  vim /etc/elasticsearch/elasticsearch.yml.
  
  173  chown -R elasticsearch:elasticsearch /var/lib/elasticsearch/.
  
  174  curl -XGET 'http://localhost:9200/filebeat-*/_search?pretty'.
  
  175  sudo service elasticsearch restart.
  
  176  ysystemctl sttaus elasticsearch.
  
  177  systemctl sttaus elasticsearch.
  
  178  systemctl status elasticsearch.
  
  180  curl -XGET 'http://localhost:9200/filebeat-*/_search?pretty'.
  
  181  curl localhost:9200.
  
  182  ls.
  
  183  cat input.csv. 
  
  184  cat output.json. 
  
  185  vim output.json.
  
  186  cat output.json.
  
  187  python3 cvv.py.
  
  188  cat output.json. 
  
  189  cat cvv.py.
  
  190  vim input.csv. 
  
  191  python3 cvv.py. 
  
  192  cat output.json. 
  
  193  history.
