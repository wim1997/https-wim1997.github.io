##elasticsearch..
elasticsearch guid 

#url: 
https://theaidigest.in/load-csv-into-elasticsearch-using-python/#:~:text=Load%20CSV%20to%20elasticsearch%20python,Also%2C%20import%20csv%20module.&text=Create%20the%20elasticsearch%20client%2C%20which%20will%20connect%20to%20Elasticsearch.&text=Then%2C%20open%20the%20CSV%20file,and%20bulk%20upload%20to%20ealsticsearch