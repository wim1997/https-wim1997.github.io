##get json file and then print it 


import pandas as pd

pdObj = pd.read_json('zadi1.json', lines=True)
print(pdObj)
~                                                                               
~                                                                               
~       